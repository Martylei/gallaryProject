from django.apps import AppConfig


class ManagerAppConfig(AppConfig):
    name = 'manager_app'
