from django.apps import AppConfig


class GalleryAppConfig(AppConfig):
    name = 'Gallery_app'
